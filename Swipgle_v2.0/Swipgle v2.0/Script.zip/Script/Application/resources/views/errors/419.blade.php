@extends('errors.layout')
@section('title', lang('Page Expired', 'error pages'))
@section('code', '419')
@section('message', lang('Page Expired', 'error pages'))
