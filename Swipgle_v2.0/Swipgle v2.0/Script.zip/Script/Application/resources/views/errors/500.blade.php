@extends('errors.layout')
@section('title', lang('Server Error', 'error pages'))
@section('code', '500')
@section('message', lang('Server Error', 'error pages'))
