@extends('errors.layout')
@section('title', lang('Service Unavailable', 'error pages'))
@section('code', '503')
@section('message', lang('Service Unavailable', 'error pages'))
