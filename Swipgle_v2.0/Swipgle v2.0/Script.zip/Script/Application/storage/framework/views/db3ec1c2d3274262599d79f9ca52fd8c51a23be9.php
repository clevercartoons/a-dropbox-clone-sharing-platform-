<script type="text/javascript">
    "use strict";
    const BASE_URL = "<?php echo e(url('/admin')); ?>";
    const PRIMARY_COLOR = "<?php echo e($settings['website_primary_color']); ?>";
    const SECONDARY_COLOR = "<?php echo e($settings['website_secondary_color']); ?>";
</script>
<?php echo $__env->yieldPushContent('top_scripts'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/sweetalert/sweetalert2.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts_libs'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/toggle-master/bootstrap-toggle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/datatable/datatables.jq.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/toastr/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/ckeditor/ckeditor.js')); ?>""></script>
<script src="<?php echo e(asset('assets/vendor/admin/js/application.js')); ?>"></script>
<?php echo app('toastr')->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/includes/scripts.blade.php ENDPATH**/ ?>