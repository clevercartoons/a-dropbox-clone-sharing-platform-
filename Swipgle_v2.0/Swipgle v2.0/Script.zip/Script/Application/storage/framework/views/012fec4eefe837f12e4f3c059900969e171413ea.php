<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<title><?php echo e($settings['website_name']); ?> <?php echo e(__('Admin')); ?> — <?php if (! empty(trim($__env->yieldContent('section')))): ?> <?php echo $__env->yieldContent('section'); ?> - <?php endif; ?> <?php echo $__env->yieldContent('title'); ?></title>
<link rel="shortcut icon" href="<?php echo e(asset($settings['website_favicon'])); ?>">
<link rel="stylesheet"
href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&amp;display=swap">
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&display=swap" rel="stylesheet">
<?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/includes/head.blade.php ENDPATH**/ ?>