<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('backend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('backend.includes.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="vironeer-page-content">
        <?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container <?php echo $__env->yieldContent('container'); ?>">
            <div class="vironeer-page-body px-1 px-sm-2 px-xxl-0">
                <div class="py-4 g-4">
                    <div class="row g-3 align-items-center">
                        <div class="col-12 col-lg">
                            <?php echo $__env->make('backend.includes.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-12 col-lg-auto">
                            <?php if (! empty(trim($__env->yieldContent('back')))): ?>
                                <a href="<?php echo $__env->yieldContent('back'); ?>" class="btn btn-secondary me-2"><i
                                        class="fas fa-arrow-left me-2"></i><?php echo e(__('Back')); ?></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('language')))): ?>
                                <div class="dropdown d-inline me-2">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-globe me-2"></i><?php echo e($active); ?>

                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                        <?php $__currentLoopData = $adminLanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adminLanguage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item <?php if($adminLanguage->name == $active): ?> active <?php endif; ?>"
                                                    href="?lang=<?php echo e($adminLanguage->code); ?>"><?php echo e($adminLanguage->name); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('link')))): ?>
                                <a href="<?php echo $__env->yieldContent('link'); ?>" class="btn btn-primary me-2"><i class="fa fa-plus"></i></a>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('modal')))): ?>
                                <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#viewModal">
                                    <?php echo $__env->yieldContent('modal'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if (! empty(trim($__env->yieldContent('add_modal')))): ?>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#addModal">
                                    <i class="fa fa-plus"></i>
                                </button>
                            <?php endif; ?>
                            <?php if(request()->routeIs('admin.transactions.edit')): ?>
                                <?php if($transaction->status != 2): ?>
                                    <button class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#cancelTransaction"><i
                                            class="far fa-times-circle me-2"></i><?php echo e(__('Cancel Transaction')); ?></button>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(request()->routeIs('admin.transfers.users.edit') || request()->routeIs('admin.transfers.guests.edit')): ?>
                                <?php if($transfer->status && !isExpiry($transfer->expiry_at)): ?>
                                    <button class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#cancelTransfer"><i
                                            class="far fa-times-circle me-2"></i><?php echo e(__('Cancel Transfer')); ?></button>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(request()->routeIs('admin.notifications.index')): ?>
                                <a class="vironeer-link-confirm btn btn-outline-success me-2"
                                    href="<?php echo e(route('admin.notifications.readall')); ?>"><?php echo e(__('Make All as Read')); ?></a>
                                <form class="d-inline" action="<?php echo e(route('admin.notifications.deleteallread')); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="vironeer-able-to-delete btn btn-outline-danger">
                                        <?php echo e(__('Delete All Read')); ?></button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row g-3 g-xl-3">
                    <div class="col">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo $__env->make('backend.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/layouts/grid.blade.php ENDPATH**/ ?>