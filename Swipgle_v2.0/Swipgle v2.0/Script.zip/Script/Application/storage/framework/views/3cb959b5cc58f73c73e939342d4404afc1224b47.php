<?php $__env->startSection('title', __('Pricing plans')); ?>
<?php $__env->startSection('link', route('admin.plans.create')); ?>
<?php $__env->startSection('content'); ?>
    <div class="card custom-card custom-tabs mb-3">
        <div class="card-body">
            <ul class="nav nav-pills" role="tablist">
                <li role="presentation">
                    <button class="nav-link active me-2" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly"
                        type="button" role="tab" aria-controls="monthly" aria-selected="true"><?php echo e(__('Monthly plans')); ?>

                        (<?php echo e(count($monthlyPlans)); ?>)</button>
                </li>
                <li role="presentation">
                    <button class="nav-link" id="yearly-tab" data-bs-toggle="tab" data-bs-target="#yearly"
                        type="button" role="tab" aria-controls="yearly" aria-selected="false"><?php echo e(__('Yearly plans')); ?>

                        (<?php echo e(count($yearlyPlans)); ?>)</button>
                </li>
            </ul>
        </div>
    </div>
    <div class="card custom-card">
        <div class="tab-content">
            <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
                <table id="datatable" class="table w-100">
                    <thead>
                        <tr>
                            <th class="tb-w-2x"><?php echo e(__('#')); ?></th>
                            <th class="tb-w-7x"><?php echo e(__('Plan name')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Storage space')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Transfer size')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Files duration')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Plan price')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Plan Interval')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Added at')); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $monthlyPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthlyPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                <td><?php echo e($monthlyPlan->id); ?></td>
                                <td>
                                    <?php echo e($monthlyPlan->name); ?>

                                    <?php echo e($monthlyPlan->featured_plan ? __('(Featured)') : ''); ?>

                                    <?php echo e($monthlyPlan->price == 0 ? __('(Free)') : ''); ?>

                                </td>
                                <td><?php echo e($monthlyPlan->storage_space == null ? __('Unlimited') : formatBytes($monthlyPlan->storage_space)); ?>

                                </td>
                                <td><?php echo e($monthlyPlan->transfer_size == null ? __('Unlimited') : formatBytes($monthlyPlan->transfer_size)); ?>

                                </td>
                                <td>
                                    <?php if($monthlyPlan->transfer_interval == 1): ?>
                                        <?php echo e($monthlyPlan->transfer_interval == null? __('Unlimited time'): $monthlyPlan->transfer_interval . ' ' . __('Day')); ?>

                                    <?php else: ?>
                                        <?php echo e($monthlyPlan->transfer_interval == null? __('Unlimited time'): $monthlyPlan->transfer_interval . ' ' . __('Days')); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong>
                                        <?php if($monthlyPlan->price == 0): ?>
                                            <span class="text-success"><?php echo e(__('Free')); ?></span>
                                        <?php else: ?>
                                            <span class="text-dark"><?php echo e(priceSymbol($monthlyPlan->price)); ?></span>
                                        <?php endif; ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php if($monthlyPlan->interval == 0): ?>
                                        <span class="badge bg-secondary"><?php echo e(__('Monthly')); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-primary"><?php echo e(__('Yearly')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(vDate($monthlyPlan->created_at)); ?></td>
                                <td>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                            aria-expanded="true">
                                            <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-sm-end" data-popper-placement="bottom-end">
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.plans.edit', $monthlyPlan->id)); ?>"><i
                                                        class="fa fa-edit me-2"></i><?php echo e(__('Edit')); ?></a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider" />
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('admin.plans.destroy', $monthlyPlan->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="vironeer-able-to-delete dropdown-item text-danger"><i
                                                            class="far fa-trash-alt me-2"></i><?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="tab-pane fade" id="yearly" role="tabpanel" aria-labelledby="yearly-tab">
                <table id="datatable2" class="table w-100">
                    <thead>
                        <tr>
                            <th class="tb-w-2x"><?php echo e(__('#')); ?></th>
                            <th class="tb-w-7x"><?php echo e(__('Plan name')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Storage space')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Transfer size')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('File duration')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Plan price')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Plan Interval')); ?></th>
                            <th class="tb-w-3x"><?php echo e(__('Added at')); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $yearlyPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearlyPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                <td><?php echo e($yearlyPlan->id); ?></td>
                                <td>
                                    <?php echo e($yearlyPlan->name); ?>

                                    <?php echo e($yearlyPlan->featured_plan ? __('(Featured)') : ''); ?>

                                    <?php echo e($yearlyPlan->price == 0 ? __('(Free)') : ''); ?>

                                </td>
                                <td><?php echo e($yearlyPlan->storage_space == null ? __('Unlimited') : formatBytes($yearlyPlan->storage_space)); ?>

                                </td>
                                <td><?php echo e($yearlyPlan->transfer_size == null ? __('Unlimited') : formatBytes($yearlyPlan->transfer_size)); ?>

                                </td>
                                <td>
                                    <?php if($yearlyPlan->transfer_interval == 1): ?>
                                        <?php echo e($yearlyPlan->transfer_interval == null ? __('Unlimited') : $yearlyPlan->transfer_interval . ' ' . __('Day')); ?>

                                    <?php else: ?>
                                        <?php echo e($yearlyPlan->transfer_interval == null ? __('Unlimited') : $yearlyPlan->transfer_interval . ' ' . __('Days')); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong>
                                        <?php if($yearlyPlan->price == 0): ?>
                                            <span class="text-success"><?php echo e(__('Free')); ?></span>
                                        <?php else: ?>
                                            <span class="text-dark"><?php echo e(priceSymbol($yearlyPlan->price)); ?></span>
                                        <?php endif; ?>
                                    </strong>
                                </td>
                                <td>
                                    <?php if($yearlyPlan->interval == 0): ?>
                                        <span class="badge bg-secondary"><?php echo e(__('Monthly')); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-primary"><?php echo e(__('Yearly')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(vDate($yearlyPlan->created_at)); ?></td>
                                <td>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                            aria-expanded="true">
                                            <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-sm-end" data-popper-placement="bottom-end">
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.plans.edit', $yearlyPlan->id)); ?>"><i
                                                        class="fa fa-edit me-2"></i><?php echo e(__('Edit')); ?></a>
                                            </li>
                                            <li>
                                                <hr class="dropdown-divider" />
                                            </li>
                                            <li>
                                                <form action="<?php echo e(route('admin.plans.destroy', $yearlyPlan->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="vironeer-able-to-delete dropdown-item text-danger"><i
                                                            class="far fa-trash-alt me-2"></i><?php echo e(__('Delete')); ?></button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/plans/index.blade.php ENDPATH**/ ?>