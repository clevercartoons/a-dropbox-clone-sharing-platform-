<?php $__env->startSection('title', __('Addons Manager')); ?>
<?php $__env->startSection('add_modal', 'Add New Addon'); ?>
<?php $__env->startSection('content'); ?>
    <div class="custom-card card">
        <table id="datatable" class="table w-100">
            <thead>
                <tr>
                    <th class="tb-w-1x"><?php echo e(__('#')); ?></th>
                    <th class="tb-w-3x"><?php echo e(__('Logo')); ?></th>
                    <th class="tb-w-7x"><?php echo e(__('Name')); ?></th>
                    <th class="tb-w-3x"><?php echo e(__('Version')); ?></th>
                    <th class="tb-w-3x"><?php echo e(__('Status')); ?></th>
                    <th class="tb-w-7x"><?php echo e(__('Added at')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="item">
                        <td><?php echo e($addon->id); ?></td>
                        <td><a href="<?php echo e(route('admin.additional.addons.edit', $addon->id)); ?>">
                                <img src="<?php echo e($addon->logo); ?>" alt="<?php echo e($addon->name); ?>" height="35">
                            </a>
                        </td>
                        <td><?php echo e($addon->name); ?></td>
                        <td><span class="badge bg-dark"><?php echo e($addon->version); ?></span></td>
                        <td>
                            <?php if($addon->status): ?>
                                <span class="badge bg-success"><?php echo e(__('Active')); ?></span>
                            <?php else: ?>
                                <span class="badge bg-danger"><?php echo e(__('Disabled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(vDate($addon->created_at)); ?></td>
                        <td>
                            <div class="text-end">
                                <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown"
                                    aria-expanded="true">
                                    <i class="fa fa-ellipsis-v fa-sm text-muted"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-sm-end" data-popper-placement="bottom-end">
                                    <li>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('admin.additional.addons.edit', $addon->id)); ?>"><i
                                                class="fa fa-edit me-2"></i><?php echo e(__('Edit')); ?></a>
                                    </li>
                                    <?php if($addon->action_text): ?>
                                        <li>
                                            <hr class="dropdown-divider" />
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(url($addon->action_link)); ?>"><i
                                                    class="fas fa-external-link-alt me-2"></i><?php echo e($addon->action_text); ?></a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModallLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel"><?php echo e(__('New Addon')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addNewForm" action="<?php echo e(route('admin.additional.addons.store')); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('Addon purchase code')); ?> : <span
                                    class="red">*</span></label>
                            <input type="text" name="purchase_code" class="form-control"
                                placeholder="<?php echo e(__('Purchase code')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('Addon files (Zip)')); ?> : <span
                                    class="red">*</span></label>
                            <input type="file" name="addon_files" class="form-control" accept=".zip" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button form="addNewForm" class="btn btn-primary"><?php echo e(__('Install')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/belove/demo.belovevn.com/public/Application/vendor/vuehoucine/trustlicence/src/Providers/../resources/views/addons/index.blade.php ENDPATH**/ ?>