<footer>
    <p class="mb-0"> &copy; <span data-year></span> <?php echo e($settings['website_name']); ?> -
        <?php echo e(__('All rights reserved.')); ?></p>
    <p class="mb-0 ms-auto"><?php echo e(__('Powered by Vironeer')); ?></p>
</footer>
<?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/includes/footer.blade.php ENDPATH**/ ?>