<?php $__env->startSection('title', __('Settings')); ?>
<?php $__env->startSection('container', 'container-max-xl'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row g-3 g-xl-3">
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.general')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('General')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Manage your website general settings')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.storage.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-database"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Storage')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Manage and set your website storage')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.smtp.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-paper-plane"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('SMTP')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Edit and update your smtp information')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('pages.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Pages')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Create and update your website pages')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admins.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Admins')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Add and update your webiste admins')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.extensions.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-plug"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Extensions')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Enable or disbale your website extensions')); ?>

                    </p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('languages.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-globe-asia"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Languages')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Add and update your website languages')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.mailtemplates.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-paint-roller"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Mail Templates')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Manage your website mail templates')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('seo.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-search"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('SEO Configurations')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Create and mange your seo configurations')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.gateways.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="far fa-credit-card"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Payment gateways')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Manage your website payment gateways')); ?></p>
                </a>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card p-1 text-center">
                <a class="setting-item p-4" href="<?php echo e(route('admin.settings.taxes.index')); ?>">
                    <div class="text-muted mb-3">
                        <i class="fas fa-percent"></i>
                    </div>
                    <h2 class="h6 mb-2"><?php echo e(__('Taxes')); ?></h2>
                    <p class="setting-item-text text-muted mb-0"><?php echo e(__('Manage your website taxes for every country')); ?>

                    </p>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.grid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/settings/index.blade.php ENDPATH**/ ?>