<aside class="vironeer-sidebar">
    <div class="overlay"></div>
    <div class="vironeer-sidebar-header">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="vironeer-sidebar-logo">
            <img src="<?php echo e(asset($settings['website_light_logo'])); ?>" alt="<?php echo e($settings['website_name']); ?>" />
        </a>
    </div>
    <div class="vironeer-sidebar-menu" data-simplebar>
        <div class="vironeer-sidebar-links">
            <p class="vironeer-sidebar-links-title mb-0"><?php echo e(__('General')); ?></p>
            <div class="vironeer-sidebar-links-cont">
                <a href="<?php echo e(route('admin.dashboard')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'dashboard'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fas fa-th-large"></i><?php echo e(__('Dashboard')); ?></span>
                    </p>
                </a>
                <a href="<?php echo e(route('admin.users.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'users'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fa fa-users"></i><?php echo e(__('Manage Users')); ?></span>
                        <?php if($unreadUsersCount): ?>
                            <span class="counter"><?php echo e($unreadUsersCount); ?></span>
                        <?php endif; ?>
                    </p>
                </a>
                <a href="<?php echo e(route('admin.subscriptions.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'subscriptions'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="far fa-gem"></i><?php echo e(__('Subscriptions')); ?></span>
                        <?php if($unreadSubscriptions): ?>
                            <span class="counter"><?php echo e($unreadSubscriptions); ?></span>
                        <?php endif; ?>
                    </p>
                </a>
                <div class="vironeer-sidebar-link <?php if(request()->segment(2) == 'transfers'): ?> active <?php endif; ?>" data-dropdown>
                    <p
                        class="vironeer-sidebar-link-title <?php echo e($unreadUsersTransfersCount || $unreadGuestsTransfersCount ? 'exclamation' : ''); ?>">
                        <span><i class="fas fa-paper-plane"></i><?php echo e(__('Manage Transfers')); ?></span>
                        <?php if($unreadUsersTransfersCount || $unreadGuestsTransfersCount): ?>
                            <span class="counter"><span class="fas fa-exclamation"></span></span>
                        <?php endif; ?>
                        <span class="arrow"><i class="fas fa-chevron-right fa-sm"></i></span>
                    </p>
                    <div class="vironeer-sidebar-link-menu">
                        <a href="<?php echo e(route('admin.transfers.users.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'users'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title">
                                <span class="me-1"><?php echo e(__('Users Transfers')); ?></span>
                                <?php if($unreadUsersTransfersCount): ?>
                                    <span class="counter"><?php echo e($unreadUsersTransfersCount); ?></span>
                                <?php endif; ?>
                            </p>
                        </a>
                        <a href="<?php echo e(route('admin.transfers.guests.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'guests'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title">
                                <span class="me-1"><?php echo e(__('Guest Transfers')); ?></span>
                                <?php if($unreadGuestsTransfersCount): ?>
                                    <span class="counter"><?php echo e($unreadGuestsTransfersCount); ?></span>
                                <?php endif; ?>
                            </p>
                        </a>
                    </div>
                </div>
                <a href="<?php echo e(route('admin.transactions.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'transactions'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fas fa-exchange-alt"></i><?php echo e(__('Transactions')); ?></span>
                        <?php if($unreadTransactionsCount): ?>
                            <span class="counter"><?php echo e($unreadTransactionsCount); ?></span>
                        <?php endif; ?>
                    </p>
                </a>
                <a href="<?php echo e(route('admin.plans.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'plans'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="far fa-credit-card"></i><?php echo e(__('Pricing Plans')); ?></span>
                    </p>
                </a>
                <a href="<?php echo e(route('admin.ratings.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'ratings'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fa fa-star"></i><?php echo e(__('Manage Ratings')); ?></span>
                        <?php if($unreadRatingsCount): ?>
                            <span class="counter"><?php echo e($unreadRatingsCount); ?></span>
                        <?php endif; ?>
                    </p>
                </a>
            </div>
        </div>
        <div class="vironeer-sidebar-links">
            <p class="vironeer-sidebar-links-title mb-0"><?php echo e(__('Application')); ?></p>
            <div class="vironeer-sidebar-links-cont">
                <div class="vironeer-sidebar-link <?php if(request()->segment(2) == 'navigation'): ?> active <?php endif; ?>" data-dropdown>
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fas fa-bars"></i><?php echo e(__('Navigation')); ?></span>
                        <span class="arrow"><i class="fas fa-chevron-right fa-sm"></i></span>
                    </p>
                    <div class="vironeer-sidebar-link-menu">
                        <a href="<?php echo e(route('admin.navbarMenu.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'navbarMenu'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Navbar Menu')); ?></span></p>
                        </a>
                        <a href="<?php echo e(route('admin.footerMenu.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'footerMenu'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Footer Menu')); ?></span></p>
                        </a>
                    </div>
                </div>
                <?php if($settings['website_blog_status']): ?>
                    <div class="vironeer-sidebar-link  <?php if(request()->segment(2) == 'blog'): ?> active <?php endif; ?>" data-dropdown>
                        <p class="vironeer-sidebar-link-title <?php echo e($commentsNeedsAction ? 'exclamation' : ''); ?>">
                            <span><i class="fas fa-rss"></i><?php echo e(__('Blog')); ?></span>
                            <?php if($commentsNeedsAction): ?>
                                <span class="counter"><span class="fas fa-exclamation"></span></span>
                            <?php endif; ?>
                            <span class="arrow"><i class="fas fa-chevron-right fa-sm"></i></span>
                        </p>
                        <div class="vironeer-sidebar-link-menu">
                            <a href="<?php echo e(route('articles.index')); ?>"
                                class="vironeer-sidebar-link <?php if(request()->segment(3) == 'articles'): ?> current <?php endif; ?>">
                                <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Articles')); ?></span></p>
                            </a>
                            <a href="<?php echo e(route('categories.index')); ?>"
                                class="vironeer-sidebar-link <?php if(request()->segment(3) == 'categories'): ?> current <?php endif; ?>">
                                <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Categories')); ?></span></p>
                            </a>
                            <a href="<?php echo e(route('comments.index')); ?>"
                                class="vironeer-sidebar-link <?php if(request()->segment(3) == 'comments'): ?> current <?php endif; ?>">
                                <p class="vironeer-sidebar-link-title">
                                    <span><?php echo e(__('Comments')); ?></span>
                                    <?php if($commentsNeedsAction): ?>
                                        <span class="counter"><?php echo e($commentsNeedsAction); ?></span>
                                    <?php endif; ?>
                                </p>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($settings['website_tickets_status']): ?>
                    <a href="<?php echo e(route('tickets.index')); ?>"
                        class="vironeer-sidebar-link <?php if(request()->routeIs('tickets.*')): ?> current <?php endif; ?>">
                        <p class="vironeer-sidebar-link-title">
                            <span><i class="far fa-life-ring"></i><?php echo e(__('Support Tickets')); ?></span>
                            <?php if($ticketsNeedsAction): ?>
                                <span class="counter"><?php echo e($ticketsNeedsAction); ?></span>
                            <?php endif; ?>
                        </p>
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.settings.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(2) == 'settings'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fa fa-cog"></i><?php echo e(__('Settings')); ?></span>
                    </p>
                </a>
            </div>
        </div>
        <div class="vironeer-sidebar-links">
            <p class="vironeer-sidebar-links-title mb-0"><?php echo e(__('Additional')); ?></p>
            <div class="vironeer-sidebar-links-cont">
                <div class="vironeer-sidebar-link <?php if(request()->segment(3) == 'popup-notice' || request()->segment(3) == 'custom-css'): ?> active <?php endif; ?>" data-dropdown>
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fas fa-plus-square"></i><?php echo e(__('Extra Features')); ?></span>
                        <span class="arrow"><i class="fas fa-chevron-right fa-sm"></i></span>
                    </p>
                    <div class="vironeer-sidebar-link-menu">
                        <a href="<?php echo e(route('admin.additional.notice')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'popup-notice'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('PopUp Notice')); ?></span></p>
                        </a>
                        <a href="<?php echo e(route('admin.additional.css')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'custom-css'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Custom CSS')); ?></span></p>
                        </a>
                    </div>
                </div>
                <a href="<?php echo e(route('admin.additional.addons.index')); ?>"
                    class="vironeer-sidebar-link <?php if(request()->segment(3) == 'addons'): ?> current <?php endif; ?>">
                    <p class="vironeer-sidebar-link-title"><i
                            class="fas fa-puzzle-piece"></i><span><?php echo e(__('Addons Manager')); ?></span></p>
                </a>
                <a href="<?php echo e(route('admin.additional.cache')); ?>" class="vironeer-link-confirm vironeer-sidebar-link">
                    <p class="vironeer-sidebar-link-title"><i
                            class="far fa-trash-alt"></i><span><?php echo e(__('Clear Cache')); ?></span></p>
                </a>
            </div>
        </div>
        <div class="vironeer-sidebar-links">
            <p class="vironeer-sidebar-links-title mb-0"><?php echo e(__('Others')); ?></p>
            <div class="vironeer-sidebar-links-cont">
                <div class="vironeer-sidebar-link <?php if(request()->segment(2) == 'others'): ?> active <?php endif; ?>" data-dropdown>
                    <p class="vironeer-sidebar-link-title">
                        <span><i class="fas fa-layer-group"></i><?php echo e(__('Manage Sections')); ?></span>
                        <span class="arrow"><i class="fas fa-chevron-right fa-sm"></i></span>
                    </p>
                    <div class="vironeer-sidebar-link-menu">
                        <a href="<?php echo e(route('admin.features.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'features'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Home Features')); ?></span></p>
                        </a>
                        <a href="<?php echo e(route('admin.faq.index')); ?>"
                            class="vironeer-sidebar-link <?php if(request()->segment(3) == 'faq'): ?> current <?php endif; ?>">
                            <p class="vironeer-sidebar-link-title"><span><?php echo e(__('Home FAQ')); ?></span></p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</aside>
<?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/includes/sidebar.blade.php ENDPATH**/ ?>