<?php $__env->startSection('title', __('Dashboard')); ?>
<?php $__env->startSection('access', 'Quick Access'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-lg-8 h-100">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Total Earnings')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e(priceSymbol($totalEarnings)); ?></p>
                <small><?php echo e(__('Taxes and fees included')); ?></small>
                <span class="vironeer-counter-box-icon">
                    <i class="fas fa-dollar-sign"></i>
                </span>
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-lg-9 h-100">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Today Earnings')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e(priceSymbol($todayEarnings)); ?></p>
                <small><?php echo e(__('Taxes and fees included')); ?></small>
                <span class="vironeer-counter-box-icon">
                    <i class="fas fa-dollar-sign"></i>
                </span>
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-lg-10 h-100">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('All Transfers')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e($totalTransfers); ?></p>
                <small><?php echo e(__('Canceled transfers included')); ?></small>
                <span class="vironeer-counter-box-icon">
                    <i class="fas fa-paper-plane"></i>
                </span>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-4 col-xxl-4">
            <div class="card vhp-460">
                <div class="vironeer-box v2">
                    <div class="vironeer-box-header mb-3">
                        <p class="vironeer-box-header-title large mb-0"><?php echo e(__('Recently transactions')); ?></p>
                        <div class="vironeer-box-header-action ms-auto">
                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown">
                                <i class="fa fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-sm-end">
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.transactions.index')); ?>"><?php echo e(__('View All')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vironeer-box-body">
                        <div class="vironeer-random-lists">
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="vironeer-random-list">
                                    <div class="vironeer-random-list-cont">
                                        <div class="vironeer-random-list-info">
                                            <div>
                                                <a class="vironeer-random-list-title fs-exact-14"
                                                    href="<?php echo e(route('admin.transactions.edit', $transaction->id)); ?>">
                                                    #<?php echo e($transaction->transaction_id); ?>

                                                </a>
                                                <p class="vironeer-random-list-text mb-0">
                                                    <?php echo e($transaction->created_at->diffforhumans()); ?>

                                                </p>
                                            </div>
                                            <div class="vironeer-random-list-action d-none d-lg-block">
                                                <span class="text-success">+
                                                    <strong><?php echo e(priceSymbol($transaction->total_price)); ?></strong>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo $__env->make('backend.includes.emptysmall', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-8 col-xxl-8">
            <div class="card">
                <div class="vironeer-box chart-bar">
                    <div class="vironeer-box-header">
                        <p class="vironeer-box-header-title large mb-0"><?php echo e(__('Earnings Statistics For This Week')); ?>

                        </p>
                        <div class="vironeer-box-header-action ms-auto">
                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown">
                                <i class="fa fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-sm-end">
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.transactions.index')); ?>"><?php echo e(__('View Transactions')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vironeer-box-body">
                        <div class="chart-bar">
                            <canvas height="380" id="vironeer-earnings-charts"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-8 col-xxl-8">
            <div class="card">
                <div class="vironeer-box chart-bar">
                    <div class="vironeer-box-header">
                        <p class="vironeer-box-header-title large mb-0"><?php echo e(__('Users Statistics For This Week')); ?></p>
                        <div class="vironeer-box-header-action ms-auto">
                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown">
                                <i class="fa fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-sm-end">
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('View All')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vironeer-box-body">
                        <div class="chart-bar">
                            <canvas height="380" id="vironeer-users-charts"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-lg-4 col-xxl-4">
            <div class="card vhp-460">
                <div class="vironeer-box v2">
                    <div class="vironeer-box-header mb-3">
                        <p class="vironeer-box-header-title large mb-0"><?php echo e(__('Recently registered')); ?></p>
                        <div class="vironeer-box-header-action ms-auto">
                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown">
                                <i class="fa fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-sm-end">
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('View All')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vironeer-box-body">
                        <div class="vironeer-random-lists">
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="vironeer-random-list">
                                    <div class="vironeer-random-list-cont">
                                        <a class="vironeer-random-list-img" href="#">
                                            <img src="<?php echo e(asset($user->avatar)); ?>" />
                                        </a>
                                        <div class="vironeer-random-list-info">
                                            <div>
                                                <a class="vironeer-random-list-title fs-exact-14"
                                                    href="<?php echo e(route('admin.users.edit', $user->id)); ?>">
                                                    <?php echo e($user->firstname . ' ' . $user->lastname); ?>

                                                </a>
                                                <p class="vironeer-random-list-text mb-0">
                                                    <?php echo e($user->created_at->diffforhumans()); ?>

                                                </p>
                                            </div>
                                            <div class="vironeer-random-list-action d-none d-lg-block">
                                                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                                    class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php echo $__env->make('backend.includes.emptysmall', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-3">
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-primary">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Transactions')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e($totalTransactions); ?></p>
                <span class="vironeer-counter-box-icon">
                    <i class="fas fa-exchange-alt"></i>
                </span>
            </div>
        </div>
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-primary">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Ratings')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e($totalRatings); ?></p>
                <span class="vironeer-counter-box-icon">
                    <i class="fa fa-star"></i>
                </span>
            </div>
        </div>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-primary">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Users')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e($totalUsers); ?></p>
                <span class="vironeer-counter-box-icon">
                    <i class="fa fa-users"></i>
                </span>
            </div>
        </div>
        <?php if($settings['website_tickets_status']): ?>
            <div class="col-12 col-lg-6 col-xxl">
                <div class="vironeer-counter-box bg-primary">
                    <h3 class="vironeer-counter-box-title"><?php echo e(__('Tickets')); ?></h3>
                    <p class="vironeer-counter-box-number"><?php echo e($totalTickets); ?></p>
                    <span class="vironeer-counter-box-icon">
                        <i class="fas fa-ticket-alt"></i>
                    </span>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12 col-lg-6 col-xxl">
            <div class="vironeer-counter-box bg-primary">
                <h3 class="vironeer-counter-box-title"><?php echo e(__('Pages')); ?></h3>
                <p class="vironeer-counter-box-number"><?php echo e($totalPages); ?></p>
                <span class="vironeer-counter-box-icon">
                    <i class="far fa-file-alt"></i>
                </span>
            </div>
        </div>
        <?php if($settings['website_blog_status']): ?>
            <div class="col-12 col-lg-6 col-xxl">
                <div class="vironeer-counter-box bg-primary">
                    <h3 class="vironeer-counter-box-title"><?php echo e(__('Articles')); ?></h3>
                    <p class="vironeer-counter-box-number"><?php echo e($totalArticles); ?></p>
                    <span class="vironeer-counter-box-icon">
                        <i class="fas fa-rss"></i>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-12 col-lg-12">
            <div class="card pb-3">
                <div class="vironeer-box chart-bar">
                    <div class="vironeer-box-header">
                        <p class="vironeer-box-header-title large mb-0">
                            <?php echo e(__('Transfers Statistics For Current Month')); ?>

                        </p>
                        <div class="vironeer-box-header-action ms-auto">
                            <button type="button" class="btn btn-sm rounded-3" data-bs-toggle="dropdown">
                                <i class="fa fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-sm-end">
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.transfers.users.index')); ?>"><?php echo e(__('Users Transfers')); ?></a>
                                </li>
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('admin.transfers.guests.index')); ?>"><?php echo e(__('Guests Transfers')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="vironeer-box-body">
                        <div class="chart-bar">
                            <canvas height="400" id="vironeer-transfers-charts"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts_libs'); ?>
        <script src="<?php echo e(asset('assets/vendor/libs/chartjs/chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/vendor/admin/js/charts.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('top_scripts'); ?>
        <script type="text/javascript">
            "use strict";
            const WEBSITE_CURRENCY = "<?php echo e(currencySymbol()); ?>";
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/belove/demo.belovevn.com/public/Application/resources/views/backend/dashboard/index.blade.php ENDPATH**/ ?>